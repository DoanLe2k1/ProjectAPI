﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CMS_API.Migrations
{
    /// <inheritdoc />
    public partial class DbContext : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Classrooms_Students_NumberOfParticipants",
                table: "Classrooms");

            migrationBuilder.DropIndex(
                name: "IX_Classrooms_NumberOfParticipants",
                table: "Classrooms");

            migrationBuilder.AddColumn<int>(
                name: "StudentId",
                table: "Classrooms",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Classrooms_StudentId",
                table: "Classrooms",
                column: "StudentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Classrooms_Students_StudentId",
                table: "Classrooms",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "StudentId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Classrooms_Students_StudentId",
                table: "Classrooms");

            migrationBuilder.DropIndex(
                name: "IX_Classrooms_StudentId",
                table: "Classrooms");

            migrationBuilder.DropColumn(
                name: "StudentId",
                table: "Classrooms");

            migrationBuilder.CreateIndex(
                name: "IX_Classrooms_NumberOfParticipants",
                table: "Classrooms",
                column: "NumberOfParticipants");

            migrationBuilder.AddForeignKey(
                name: "FK_Classrooms_Students_NumberOfParticipants",
                table: "Classrooms",
                column: "NumberOfParticipants",
                principalTable: "Students",
                principalColumn: "StudentId");
        }
    }
}
