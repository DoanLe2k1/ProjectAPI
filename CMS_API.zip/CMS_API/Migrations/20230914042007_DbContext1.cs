﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CMS_API.Migrations
{
    /// <inheritdoc />
    public partial class DbContext1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ScoreTypes",
                columns: table => new
                {
                    ScoreTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ScoreTypeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ScoreTypes", x => x.ScoreTypeId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Transcripts_ScoreTypeId",
                table: "Transcripts",
                column: "ScoreTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Transcripts_ScoreTypes_ScoreTypeId",
                table: "Transcripts",
                column: "ScoreTypeId",
                principalTable: "ScoreTypes",
                principalColumn: "ScoreTypeId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Transcripts_ScoreTypes_ScoreTypeId",
                table: "Transcripts");

            migrationBuilder.DropTable(
                name: "ScoreTypes");

            migrationBuilder.DropIndex(
                name: "IX_Transcripts_ScoreTypeId",
                table: "Transcripts");
        }
    }
}
