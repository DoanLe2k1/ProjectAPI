﻿using System.ComponentModel.DataAnnotations;

namespace CMS_API.Models
{
    public class ScoreType
    {
        [Key]
        public int ScoreTypeId { get; set; }
        public string ScoreTypeName { get; set; }
        public virtual ICollection<Transcript> Transcripts { get; set; }
    }
}
