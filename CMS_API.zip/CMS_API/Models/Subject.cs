﻿using System.ComponentModel.DataAnnotations;

namespace CMS_API.Models
{
    public class Subject
    {
        [Key]
        public int SubjectId { get; set; }
        public string SubjectName { get; set; }
    }
}
