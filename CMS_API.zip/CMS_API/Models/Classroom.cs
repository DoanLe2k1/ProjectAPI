﻿using CMS_API.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace User_GhiDanhAPI.Models
{
    public class Classroom
    {
        [Key]
        public int ClassId { get; set; }
        public string ClassName { get; set; }
        public int SchoolYear { get; set; }
        [ForeignKey("Classroom")]
        public int? TeacherId { get; set; }
        public Teacher Teacher { get; set; }
        public string GroupSubjectId { get; set; }
        [ForeignKey("Classroom")]
        public int? NumberOfParticipants { get; set; }
        public Student Student { get; set; }
        public string Status { get; set; }
        public int Price { get; set; }
        public string Description { get; set; }
        public string PictureURL { get; set; }
        public virtual ICollection<Bill> Bill { get; set; }
    }
}
