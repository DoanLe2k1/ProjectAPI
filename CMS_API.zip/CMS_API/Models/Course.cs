﻿using System.ComponentModel.DataAnnotations;

namespace User_GhiDanhAPI.Models
{
    public class Course
    {
        [Key]
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public DateOnly OpenDate { get; set; }
        public string Description { get; set; }
        public int NumberOfParticipants { get; set; }
        public int Price { get; set; }

    }
}
