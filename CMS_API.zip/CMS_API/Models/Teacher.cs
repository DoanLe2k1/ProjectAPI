﻿using System.ComponentModel.DataAnnotations;
using User_GhiDanhAPI.Models;

namespace CMS_API.Models
{
    public class Teacher
    {
        [Key]
        public int IdTeacher { get; set; }
        public int TaxCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string TeacherPhoneNumber { get; set; }
        public string TeacherAddress { get; set; }
        public string MainSubject { get; set; }
        public string ConcurrentlySubject { get; set; }
        public string Password { get; set; }
        public string PictureURL { get; set; }
        public virtual ICollection<Classroom> Classrooms { get; set; }
    }
}
