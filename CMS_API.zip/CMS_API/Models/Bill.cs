﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using User_GhiDanhAPI.Models;

namespace CMS_API.Models
{
    public class Bill
    {
        [Key]
        public int BillId { get; set; }
        [ForeignKey("Bill")]
        public int? StudentId { get; set; }
        public Student student { get; set; }
        [ForeignKey("Bill")]
        public int? IdClassroom { get; set; }
        public Classroom classroom { get; set; }
        public int Price { get; set; }
        public int BillStatus { get; set;}
        public string BillDescription { get; set;}
        public int DateRegister { get; set; }
        public int Discount { get; set;}
        public int Surcharge { get; set;}
        public int Total { get; set; }
    }
}
