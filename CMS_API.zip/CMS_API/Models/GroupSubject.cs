﻿using System.ComponentModel.DataAnnotations;

namespace CMS_API.Models
{
    public class GroupSubject
    {
        [Key]
        public int GroupSubjectId { get; set; }
        public string NameSubject { get; set; }
        public string GroupSubjectName { get; set; }
        public int SubjectId { get; set; }
    }
}
