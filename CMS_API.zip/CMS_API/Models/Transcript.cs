﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using User_GhiDanhAPI.Models;

namespace CMS_API.Models
{
    public class Transcript
    {
        [Key]
        public int Id { get; set; }
        public int CourseId { get; set; }
        [ForeignKey("Transcript")]
        public int? ScoreTypeId { get; set; }
        public ScoreType scoreType { get; set; }
        public int? StudentId { get; set; }
        [ForeignKey("Transcript")]
        public Student Student { get; set; }
        
    }
}
