﻿using CMS_API.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using User_GhiDanhAPI.Models;

namespace CMS_API
{
    public class WebAPIDbContext : DbContext
    {
        public WebAPIDbContext(DbContextOptions<WebAPIDbContext> otp) : base(otp)
        {

        }
        public DbSet<Bill> Bills { get; set; }
        public DbSet<Classroom> Classrooms { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Transcript> Transcripts { get; set; }
        public DbSet<ScoreType> ScoreTypes { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
    }
}
