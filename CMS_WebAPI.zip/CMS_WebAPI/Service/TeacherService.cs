﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CMS_WebAPI.Service
{
    public class TeacherService : ITeacherService
    {
        private readonly List<Teacher> _teachers;
        private readonly AccountDbContext _dbContext;
        public async Task<List<Teacher>> GetAllTeacher()
        {
            return await _dbContext.Teachers.ToListAsync();
        }
        public TeacherService(AccountDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Teacher> AddTeacher(Teacher teacher)
        {
            _dbContext.Teachers.Add(teacher);
            await _dbContext.SaveChangesAsync();
            return teacher;
        }

        public async Task<bool> DeleteTeacher(int TeacherId)
        {
            var teacher = await _dbContext.Teachers.FindAsync(TeacherId);
            if (teacher == null)
                return false;
            _dbContext.Teachers.Remove(teacher);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateTeacher(Teacher teacher)
        {
            _dbContext.Entry(teacher).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }
        public List<Teacher> SearchTeachers(string keyword)
        {

            return _dbContext.Teachers
                .Where(s =>
                    s.TeacherId.ToString().Contains(keyword) ||
                    s.TeacherFirstName.Contains(keyword) ||
                    s.TeacherLastName.Contains(keyword))
                .ToList();
        }
    }
}
