﻿namespace CMS_WebAPI.Service
{
    public interface IAuthenticationService
    {
        bool Register(string email, string password, string role);
        bool Login(string email, string password);
    }
}
