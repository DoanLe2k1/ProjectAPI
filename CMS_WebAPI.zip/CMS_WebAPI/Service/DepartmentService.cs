﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;

namespace CMS_WebAPI.Service
{
    public class DepartmentService : IDepartmentService
    {
        private readonly List<Course> _courses;
        private readonly AccountDbContext _dbContext;
        public DepartmentService(AccountDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IEnumerable<Department> GetDepartments()
        {
            return _dbContext.Departments.ToList();
        }

        public Department GetDepartmentById(string nameDepartment)
        {
            return _dbContext.Departments.FirstOrDefault(c => c.NameDepartment == nameDepartment);
        }

        public void AddDepartment(Department department)
        {
            _dbContext.Departments.Add(department);
            _dbContext.SaveChanges();
        }

        public void UpdateDepartment(string nameDepartment, Department updatedDepartment)
        {
            var department = _dbContext.Departments.FirstOrDefault(c => c.NameDepartment == nameDepartment);

            if (department != null)
            {
                department.NameDepartment = updatedDepartment.NameDepartment;
                _dbContext.SaveChanges();
            }
        }
        public void DeleteDepartment(string nameDepartment)
        {
            var department = _dbContext.Departments.FirstOrDefault(c => c.NameDepartment == nameDepartment);

            if (department != null)
            {
                _dbContext.Departments.Remove(department);
                _dbContext.SaveChanges();
            }
        }
    }
}
