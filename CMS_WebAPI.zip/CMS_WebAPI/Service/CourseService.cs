﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMS_WebAPI.Service
{
    public class CourseService : ICourseService
    {
        private readonly List<Course> _courses;
        private readonly AccountDbContext _dbContext;
        public CourseService(AccountDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IEnumerable<Course> GetCourses()
        {
            return _dbContext.Courses.ToList();
        }

        public Course GetCourseById(string courseId)
        {
            return _dbContext.Courses.FirstOrDefault(c => c.CourseId == courseId);
        }

        public void AddCourse(Course course)
        {
            _dbContext.Courses.Add(course);
            _dbContext.SaveChanges();
        }

        public void UpdateCourse(string courseId, Course updatedCourse)
        {
            var course = _dbContext.Courses.FirstOrDefault(c => c.CourseId == courseId);

            if (course != null)
            {
                course.Name = updatedCourse.Name;
                course.StartingDay = updatedCourse.StartingDay;
                course.EndingDay = updatedCourse.EndingDay;

                _dbContext.SaveChanges();
            }
        }

        public void DeleteCourse(string courseId)
        {
            var course = _dbContext.Courses.FirstOrDefault(c => c.CourseId == courseId);

            if (course != null)
            {
                _dbContext.Courses.Remove(course);
                _dbContext.SaveChanges();
            }
        }
    }
}
