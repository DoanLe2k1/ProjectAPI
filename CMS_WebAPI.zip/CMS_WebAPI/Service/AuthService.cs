﻿using CMS_WebAPI.Data;

namespace CMS_WebAPI.Service
{
    public class AuthService
    {
        private readonly AccountDbContext _context;
        private readonly JwtService _jwtService;

        public AuthService(AccountDbContext context, JwtService jwtService)
        {
            _context = context;
            _jwtService = jwtService;
        }

        public string Authenticate(string Email, string Password, string Role)
        {
            var account = _context.accounts.FirstOrDefault(u => u.Email == Email && u.Password == Password && u.Role == Role);

            if (account != null)
            {
                return _jwtService.GenerateToken(Email, Role);
            }
            return null;
        }
    }
}
