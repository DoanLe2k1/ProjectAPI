﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CMS_WebAPI.Service
{
    public class StudentService : IStudentService
    {
        private readonly AccountDbContext _dbContext;
        public async Task<List<Student>> GetAllStudents()
        {
            return await _dbContext.Students.ToListAsync();
        }
        public StudentService(AccountDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Student> AddStudent(Student student)
        {
            _dbContext.Students.Add(student);
            await _dbContext.SaveChangesAsync();
            return student;
        }

        public async Task<bool> DeleteStudent(int studentId)
        {
            var student = await _dbContext.Students.FindAsync(studentId);
            if (student == null)
                return false;
            _dbContext.Students.Remove(student);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateStudent(Student student)
        {
            _dbContext.Entry(student).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }
        public List<Student> SearchStudents(string keyword)
        {
            int phoneNumber;
            bool isNumeric = int.TryParse(keyword, out phoneNumber);

            return _dbContext.Students
                .Where(s =>
                    s.StudentId.ToString().Contains(keyword) ||
                    s.FirstName.Contains(keyword) ||
                    s.LastName.Contains(keyword) ||
                    s.Email.Contains(keyword) ||
                    (isNumeric && s.PhoneNumber == phoneNumber))
                .ToList();
        }
        public List<StudentScore> GetScore()
        {
            var score = (from p in _dbContext.Students
                        join pm in _dbContext.Subjects on p.StudentId equals pm.SubjectId
                        join pd in _dbContext.Transcripts on p.StudentId equals pd.StudentId
                        select new StudentScore()
                        {
                            StudentId = p.StudentId,
                            FirstName = p.FirstName,
                            LastName = p.LastName,
                            SubjectName = pm.SubjectName,
                            TranscriptId = p.TranscriptId,
                            FirstColumnScore = pd.FirstColumnScore,
                            SecondColumnScore = pd.SecondColumnScore,
                            ThirdColumnScore = pd.ThirdColumnScore,
                            FourthColumnScore  = pd.FourthColumnScore,
                            FinalExamScore = pd.FinalExamScore,
                            AverageScore = pd.AverageScore
                        }).ToList();
            return score;
        }
    }
}
