﻿using CMS_WebAPI.Models;

namespace CMS_WebAPI.Service
{
    public interface IDepartmentService
    {
        IEnumerable<Department> GetDepartments();
        Department GetDepartmentById(string nameDepartment);
        void AddDepartment(Department department);
        void UpdateDepartment(string nameDepartment, Department updatedDepartment);
        void DeleteDepartment(string nameDepartment);
    }
}
