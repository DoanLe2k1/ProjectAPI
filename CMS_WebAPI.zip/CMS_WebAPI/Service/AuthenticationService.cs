﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;

namespace CMS_WebAPI.Service
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly AccountDbContext _dbContext;

        public AuthenticationService(AccountDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public bool Register(string email, string password, string role)
        {
            // Kiểm tra xem email đã tồn tại trong cơ sở dữ liệu chưa
            if (_dbContext.Accounts.Any(a => a.Email == email))
            {
                return false; // Email đã tồn tại, không thể đăng ký
            }

            var account = new Account
            {
                Email = email,
                Password = password,
                Role = role
            };

            _dbContext.Accounts.Add(account);
            _dbContext.SaveChanges();

            return true; // Đăng ký thành công
        }

        public bool Login(string email, string password)
        {
            var account = _dbContext.Accounts.FirstOrDefault(a => a.Email == email && a.Password == password);

            if (account != null)
            {
                return true; // Đăng nhập thành công
            }
            return false; // Đăng nhập không thành công
        }
    }
}

