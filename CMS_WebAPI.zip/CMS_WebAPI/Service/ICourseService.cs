﻿using CMS_WebAPI.Models;

namespace CMS_WebAPI.Service
{
    public interface ICourseService
    {
        IEnumerable<Course> GetCourses();
        Course GetCourseById(string courseId);
        void AddCourse(Course course);
        void UpdateCourse(string courseId, Course updatedCourse);
        void DeleteCourse(string courseId);
    }
}
