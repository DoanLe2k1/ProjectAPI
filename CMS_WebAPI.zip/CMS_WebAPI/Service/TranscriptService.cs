﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CMS_WebAPI.Service
{
    public class TranscriptService : ITranscriptService
    {
        private readonly List<Transcript> _transcript;
        private readonly AccountDbContext _dbContext;
        public async Task<List<Transcript>> GetAllTranscripts()
        {
            return await _dbContext.Transcripts.ToListAsync();
        }
        public TranscriptService(AccountDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Transcript> AddTranscript(Transcript transcript)
        {
            _dbContext.Transcripts.Add(transcript);
            await _dbContext.SaveChangesAsync();
            return transcript;
        }

        public async Task<bool> DeleteTranscript(int TranscriptId)
        {
            var transcript = await _dbContext.Transcripts.FindAsync(TranscriptId);
            if (transcript == null)
                return false;
            _dbContext.Transcripts.Remove(transcript);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateTranscript(Transcript transcript)
        {
            _dbContext.Entry(transcript).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }
        public List<Transcript> SearchTranscript(string keyword)
        {

            return _dbContext.Transcripts
                .Where(s =>
                    s.TranscriptId.ToString().Contains(keyword) ||
                    s.StudentId.ToString().Contains(keyword) ||
                    s.SubjectId.ToString().Contains(keyword))
                .ToList();
        }
        public List<StudentScore> GetScore()
        {
            var score = (from p in _dbContext.Students
                         join pm in _dbContext.Subjects on p.StudentId equals pm.SubjectId
                         join pd in _dbContext.Transcripts on p.StudentId equals pd.StudentId
                         select new StudentScore()
                         {
                             StudentId = p.StudentId,
                             FirstName = p.FirstName,
                             LastName = p.LastName,
                             SubjectName = pm.SubjectName,
                             TranscriptId = p.TranscriptId,
                             FirstColumnScore = pd.FirstColumnScore,
                             SecondColumnScore = pd.SecondColumnScore,
                             ThirdColumnScore = pd.ThirdColumnScore,
                             FourthColumnScore = pd.FourthColumnScore,
                             FinalExamScore = pd.FinalExamScore,
                             AverageScore = pd.AverageScore
                         }).ToList();
            return score;
        }
    }
}
