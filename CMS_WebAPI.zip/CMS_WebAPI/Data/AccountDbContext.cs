﻿using CMS_WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CMS_WebAPI.Data
{
    public class AccountDbContext : DbContext
    {
        public AccountDbContext(DbContextOptions<AccountDbContext> options) : base(options)
        {

        }
        public DbSet<Account> accounts { get; set; }
        public DbSet<Student> Students { get; set; }
    }
}
