﻿using System.ComponentModel.DataAnnotations;

namespace CMS_WebAPI.Models
{
    public class Department
    {
        [Key]
        public string NameDepartment { get; set; }
    }
}
