﻿namespace CMS_WebAPI.Models
{
    public class Course
    {
        public string CourseId { get; set; }
        public string Name { get; set; }
        public string StartingDay { get; set; }
        public string EndingDay { get; set;}
    }
}
