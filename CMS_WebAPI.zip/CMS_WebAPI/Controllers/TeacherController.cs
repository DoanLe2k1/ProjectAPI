﻿using CMS_WebAPI.Models;
using CMS_WebAPI.Service;
using Microsoft.AspNetCore.Mvc;

namespace CMS_WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TeacherController : ControllerBase
    {
        private readonly ITeacherService _teacherService;
        public TeacherController(ITeacherService teacherService)
        {
            _teacherService = teacherService;
        }
        [HttpGet("List Teachers")]
        public async Task<ActionResult<List<Teacher>>> GetAllTeacher()
        {
            var teachers = await _teacherService.GetAllTeacher();
            return Ok(teachers);
        }
        [HttpPost("Add Teacher")]
        public async Task<ActionResult<Teacher>> AddTeacher(Teacher teacher)
        {
            var addedteacher = await _teacherService.AddTeacher(teacher);
            if (addedteacher != null)
            {
                return Ok(new { message = "Thêm giáo viên thành công", teacher = addedteacher });
            }
            else
            {
                return BadRequest(new { message = "Thêm giáo viên thất bại" });
            }
        }

        [HttpDelete("Delete Teacher")]
        public async Task<ActionResult> DeleteTeacher(int teacherId)
        {
            var deleted = await _teacherService.DeleteTeacher(teacherId);
            if (deleted)
            {
                return Ok(new { message = "Xóa giáo viên thành công" });
            }
            else
            {
                return NotFound(new { message = "Không tìm thấy sinh viên" });
            }
        }

        [HttpPut("Update Teacher")]
        public async Task<ActionResult> UpdateTeacher(int teacherId, Teacher teacher)
        {
            if (teacherId != teacher.TeacherId)
                return BadRequest(new { message = "Dữ liệu không hợp lệ" });

            var updated = await _teacherService.UpdateTeacher(teacher);
            if (updated)
            {
                return Ok(new { message = "Cập nhật giáo viên thành công" });
            }
            else
            {
                return NotFound(new { message = "Không tìm thấy giáo viên" });
            }
        }
        [HttpGet("Search Teacher")]
        public IActionResult SearchTeachers(string keyword)
        {
            var teachers = _teacherService.SearchTeachers(keyword);
            return Ok(teachers);
        }
    }
}
