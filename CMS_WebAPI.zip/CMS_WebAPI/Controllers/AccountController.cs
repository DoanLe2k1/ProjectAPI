﻿using CMS_WebAPI.Models;
using CMS_WebAPI.Service;
using Microsoft.AspNetCore.Mvc;

namespace CMS_WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : ControllerBase
    {
        private readonly IAuthenticationService _authenticationService;

        public AccountController(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        [HttpPost("Register")]
        public IActionResult Register(Account regierterAccount)
        {
            bool success = _authenticationService.Register(regierterAccount.Email, regierterAccount.Password, regierterAccount.Role);

            if (success)
            {
                return Ok("Đăng ký thành công.");
            }

            return BadRequest("Email đã tồn tại.");
        }

        [HttpPost("Login")]
        public IActionResult Login(AccountRequest accountRequest)
        {
            bool success = _authenticationService.Login(accountRequest.Email, accountRequest.Password);

            if (success)
            {
                return Ok("Đăng nhập thành công!");

            }

            return BadRequest("Email hoặc mật khẩu không đúng.");
        }
    }
}
