﻿using CMS_WebAPI.Models;
using CMS_WebAPI.Service;
using Microsoft.AspNetCore.Mvc;

namespace CMS_WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpPost]
        public async Task<ActionResult<Student>> AddStudent(Student student)
        {
            var addedStudent = await _studentService.AddStudent(student);
            return Ok(addedStudent);
        }

        [HttpDelete("{studentId}")]
        public async Task<ActionResult> DeleteStudent(int studentId)
        {
            var deleted = await _studentService.DeleteStudent(studentId);
            if (deleted)
                return NoContent();
            else
                return NotFound();
        }

        [HttpPut("{studentId}")]
        public async Task<ActionResult> UpdateStudent(int studentId, Student student)
        {
            if (studentId != student.StudentId)
                return BadRequest();

            var updated = await _studentService.UpdateStudent(student);
            if (updated)
                return NoContent();
            else
                return NotFound();
        }
    }
}
