﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;
using CMS_WebAPI.Service;
using Microsoft.AspNetCore.Mvc;

namespace CMS_WebAPI.Controllers
{
    public class CourseController : Controller
    {
        private readonly ICourseService _courseService;
        private readonly AccountDbContext _dbContext;
        public CourseController(ICourseService courseService)
        {
            _courseService = courseService;
        }
        [HttpGet("Course Lists")]
        public ActionResult<IEnumerable<Course>> GetCourses()
        {
            var courses = _courseService.GetCourses();
            return Ok(courses);
        }
        [HttpGet("Get Course")]
        public ActionResult<Course> GetCourse(string id)
        {
            var course = _courseService.GetCourseById(id);

            if (course == null)
            {
                return NotFound();
            }

            return Ok(course);
        }
  
        [HttpPost("Add Course")]
        public IActionResult CreateCourse(Course course)
        {
            _courseService.AddCourse(course);
            return CreatedAtAction(nameof(GetCourse), new { id = course.CourseId }, course);
        }
        [HttpPut("Update Course")]
        public IActionResult UpdateCourse(string id, Course updatedCourse)
        {
            _courseService.UpdateCourse(id, updatedCourse);
            return NoContent();
        }

        [HttpDelete("Delete Course")]
        public IActionResult DeleteCourse(string id)
        {
            _courseService.DeleteCourse(id);
            return NoContent();
        }
    }
}
