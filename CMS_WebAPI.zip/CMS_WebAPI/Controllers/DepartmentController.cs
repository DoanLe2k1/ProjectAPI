﻿using CMS_WebAPI.Data;
using CMS_WebAPI.Models;
using CMS_WebAPI.Service;
using Microsoft.AspNetCore.Mvc;

namespace CMS_WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DepartmentController : Controller
    {
        private readonly IDepartmentService _departmentService;
        private readonly AccountDbContext _dbContext;
        public DepartmentController(IDepartmentService departmentService)
        {
            _departmentService = departmentService;
        }
        [HttpGet("Department Lists")]
        public ActionResult<IEnumerable<Department>> GetDepartments()
        {
            var departments = _departmentService.GetDepartments();
            return Ok(departments);
        }
        [HttpGet("Get Department by Name")]
        public ActionResult<Department> GetDepartmentById(string id)
        {
            var department = _departmentService.GetDepartmentById(id);

            if (department == null)
            {
                return NotFound();
            }

            return Ok(department);
        }

        [HttpPost("Add Department")]
        public IActionResult CreateDepartment(Department department)
        {
            _departmentService.AddDepartment(department);
            return CreatedAtAction(nameof(GetDepartments), new { id = department.NameDepartment }, department);
        }
        [HttpPut("Update Department")]
        public IActionResult UpdateDepartment(string nameDepartment, Department updatedDepartment)
        {
            _departmentService.UpdateDepartment(nameDepartment, updatedDepartment);
            return NoContent();
        }

        [HttpDelete("Delete Course")]
        public IActionResult DeleteDepartment(string nameDepartment)
        {
            _departmentService.DeleteDepartment(nameDepartment);
            return NoContent();
        }
    }
}
