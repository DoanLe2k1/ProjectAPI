﻿using CMS_WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace Student_WebAPI.Data
{
    public class StudentDbContext : DbContext
    {
        public StudentDbContext(DbContextOptions<StudentDbContext> options) : base(options)
        {

        }
        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>()
               .HasKey(p => p.StudentId);
            modelBuilder.Entity<Student>()
                    .Property(p => p.StudentId)
                    .ValueGeneratedNever();
        }
       
    }
}
