﻿using CMS_WebAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Student_WebAPI.Data
{
    public class TeacherDbContext : DbContext
    {
        public TeacherDbContext(DbContextOptions<TeacherDbContext> options) : base(options)
        {

        }
        public DbSet<Teacher> Teachers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Teacher>()
                .HasKey(p => p.TeacherId);
            modelBuilder.Entity<Teacher>()
                .Property(p => p.TeacherId)
                .ValueGeneratedNever();
        }
       
    }
}
