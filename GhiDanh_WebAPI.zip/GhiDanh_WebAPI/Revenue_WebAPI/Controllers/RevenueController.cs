﻿using Microsoft.AspNetCore.Mvc;

namespace Revenue_WebAPI.Controllers
{
    public class RevenueController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
