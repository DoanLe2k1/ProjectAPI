﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CMS_WebAPI.Models
{
    public class Account
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }

    }
}
