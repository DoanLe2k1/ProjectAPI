﻿using CMS_WebAPI.Models;

namespace CMS_WebAPI.Service
{
    public interface IAuthenticationService
    {
        Task<List<Account>> GetAllAccounts();
        bool Register(string email, string password, string role);
        bool Login(string email, string password);
    }
}
