﻿namespace Education_WebAPI.Models
{
    public class Revenue
    {
        public int RevenueId { get; set; }
        public int StudentId { get; set; }
        public int ClassroomId { get; set; }
        public int Price { get; set; }
        public int TeacherId { get; set; }
    }
}
