﻿namespace Education_WebAPI.Models
{
    public class Score
    {
        public int ScoreId { get; set; }
        public string CourseName { get; set; }
        public string ScoreName { get; set; }
        public string ScoreTypeId { get; set; }
        public int ScoreColumn { get; set; }
        public int RequiredScoreColumn { get; set; } 

    }
}
