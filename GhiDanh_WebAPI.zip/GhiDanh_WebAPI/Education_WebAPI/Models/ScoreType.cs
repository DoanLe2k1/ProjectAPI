﻿namespace Education_WebAPI.Models
{
    public class ScoreType
    {
        public int ScoreTypeId { get; set; }
        public int ScoreName { get; set; }
        public int Coefficient { get; set; }
    }
}
