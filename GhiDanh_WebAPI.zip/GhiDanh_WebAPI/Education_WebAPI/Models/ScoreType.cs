﻿namespace Education_WebAPI.Models
{
    public class ScoreType
    {
        public int ScoreTypeId { get; set; }
        public string ScoreName { get; set; }
        public int Coefficient { get; set; }
    }
}
