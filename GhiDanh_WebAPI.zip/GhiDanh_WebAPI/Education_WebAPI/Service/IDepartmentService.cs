﻿using Education_WebAPI.Models;

namespace Education_WebAPI.Service
{
    public interface IDepartmentService
    {
        Task<List<Department>> GetAllDepartments();
        Task<Department> AddDepartment(Department department);
        Task<bool> DeleteDepartment(int departmentId);
        Task<bool> UpdateDepartment(Department department);
        List<Department> SearchDepartments(string keyword);
    }
}
