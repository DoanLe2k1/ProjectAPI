﻿using CMS_WebAPI.Models;
using Education_WebAPI.Models;

namespace Education_WebAPI.Service
{
    public interface IClassroomService
    {
        Task<List<Classroom>> GetAllClassrooms();
        Task<Classroom> AddClassroom(Classroom classroom);
        Task<bool> DeleteClassroom(int classroomId);
        Task<bool> UpdateClassroom(Classroom classroom);
        List<Classroom> SearchClassrooms(string keyword);
        void AddOrUpdateAvatar(int classroomId, string PictureURL);
        void DeleteAvatar(int classroomId);
    }
}
