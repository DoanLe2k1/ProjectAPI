﻿namespace Education_WebAPI.Service
{
    public class TypeScoreService
    {
    }
}
