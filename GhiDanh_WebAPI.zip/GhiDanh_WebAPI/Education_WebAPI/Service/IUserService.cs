﻿namespace Education_WebAPI.Service
{
    public interface IUserService
    {
        string GetMyName();
    }
}
