﻿namespace Education_WebAPI.Service
{
    public interface ITypeScoreService
    {
    }
}
