﻿using CMS_WebAPI.Models;
using Education_WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace Education_WebAPI.Data
{
    public class EducationDbContext : DbContext
    {
        public EducationDbContext(DbContextOptions<EducationDbContext> options) : base(options)
        {

        }

        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Transcript> Transcripts { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Classroom> Classrooms { get; set; }
        public DbSet<Score> Scores { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Course>()
                .HasKey(p => p.CourseId);
            modelBuilder.Entity<Course>()
                .Property(p => p.CourseId)
                .ValueGeneratedNever();
            modelBuilder.Entity<Department>()
                .HasKey(p => p.DepartmentId);
            modelBuilder.Entity<Department>()
                .Property(p => p.DepartmentId)
                .ValueGeneratedNever();
            modelBuilder.Entity<StudentScore>()
                .HasKey(p => p.StudentId);
            modelBuilder.Entity<StudentScore>()
                .Property(p => p.StudentId)
                .ValueGeneratedNever();
            modelBuilder.Entity<Subject>()
                .HasKey(p => p.SubjectId);
            modelBuilder.Entity<Subject>()
                .Property(p => p.SubjectId)
                .ValueGeneratedNever();
            modelBuilder.Entity<Transcript>()
                .HasKey(p => p.TranscriptId);
            modelBuilder.Entity<Transcript>()
                .Property(p => p.TranscriptId)
                .ValueGeneratedNever();
            modelBuilder.Entity<Classroom>()
                .HasKey(p => p.ClassroomId);
            modelBuilder.Entity<Classroom>()
                .Property(p => p.ClassroomId)
                .ValueGeneratedNever();
            modelBuilder.Entity<Score>()
              .HasKey(p => p.ScoreId);
            modelBuilder.Entity<Score>()
                .Property(p => p.ScoreId)
                .ValueGeneratedNever();
        }
    }
}
